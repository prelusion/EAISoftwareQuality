package com.qbuzz.soapserver;

import java.util.ArrayList;

public class Bericht {
	public String lijnNaam;
	public String eindpunt;
	public String bedrijf;
	public String busID;
	public int tijd;
	public ArrayList<ETA> ETAs;
}
