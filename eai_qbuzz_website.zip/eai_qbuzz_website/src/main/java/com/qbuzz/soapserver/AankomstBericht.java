package com.qbuzz.soapserver;

public class AankomstBericht {
	
	public String busID;
	public String lijn;
	public String eindpunt;
	public int aankomsttijd;
	
}
