package com.qbuzz.soapserver;

public class HalteBericht {
	
	public String busID;
	public String lijn;
	public String halte;
	public int tijd;
	public String eindpunt;
	
}
