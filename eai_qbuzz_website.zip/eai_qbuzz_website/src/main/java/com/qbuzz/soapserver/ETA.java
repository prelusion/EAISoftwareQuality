package com.qbuzz.soapserver;

public class ETA {
	public String halteNaam;
	public int richting;
	public int aankomsttijd;
}
